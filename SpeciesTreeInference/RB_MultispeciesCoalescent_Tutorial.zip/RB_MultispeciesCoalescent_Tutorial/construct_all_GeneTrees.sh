

# construct the command string
rb_command="i = 1;
            source(\"scripts/mcmc_GeneTree.Rev\");"

# pipe the command into RevBayes
echo $rb_command | rb&

# construct the command string
rb_command="i = 2;
            source(\"scripts/mcmc_GeneTree.Rev\");"

# pipe the command into RevBayes
echo $rb_command | rb&

# construct the command string
rb_command="i = 3;
            source(\"scripts/mcmc_GeneTree.Rev\");"

# pipe the command into RevBayes
echo $rb_command | rb&

# construct the command string
rb_command="i = 4;
            source(\"scripts/mcmc_GeneTree.Rev\");"

# pipe the command into RevBayes
echo $rb_command | rb&

# construct the command string
rb_command="i = 5;
            source(\"scripts/mcmc_GeneTree.Rev\");"

# pipe the command into RevBayes
echo $rb_command | rb&

# construct the command string
rb_command="i = 6;
            source(\"scripts/mcmc_GeneTree.Rev\");"

# pipe the command into RevBayes
echo $rb_command | rb&

# construct the command string
rb_command="i = 7;
            source(\"scripts/mcmc_GeneTree.Rev\");"

# pipe the command into RevBayes
echo $rb_command | rb&

# construct the command string
rb_command="i = 8;
            source(\"scripts/mcmc_GeneTree.Rev\");"

# pipe the command into RevBayes
echo $rb_command | rb&

# construct the command string
rb_command="i = 9;
            source(\"scripts/mcmc_GeneTree.Rev\");"

# pipe the command into RevBayes
echo $rb_command | rb&

# construct the command string
rb_command="i = 10;
            source(\"scripts/mcmc_GeneTree.Rev\");"

# pipe the command into RevBayes
echo $rb_command | rb&
