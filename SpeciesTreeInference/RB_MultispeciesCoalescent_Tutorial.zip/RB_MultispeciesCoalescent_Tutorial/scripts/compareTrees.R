#This script uses a package of phylogenetic tools called ape. Start by installing it.
install.packages("ape")
library(ape)

#set your working directory appropriately
setwd("~/Desktop/RB_MultispeciesCoalescent_Tutorial")

## simple example to show how this works
a <- read.tree(text = "(a,b,(c,d));")
b <- read.tree(text = "(a,c,(b,d));")
comparePhylo(a, b, plot = TRUE, force.rooted = TRUE)

#read in two trees, and use the comparePhylo fucntion to plot their differences.
COIII <- read.nexus(file = "./output_GeneTrees/COIII_MAP.tree")
FGA <- read.nexus(file = "output_GeneTrees/FGA_MAP.tree")
comparePhylo(COIII, FGA, plot = TRUE, force.rooted = TRUE, use.edge.length = FALSE)